BJJ MOBILE AUDIO PACK

Original first-pass music + SFX for a mobile jiu-jitsu game.

MOBILE:
  mobile_ogg/music = compressed music
  mobile_ogg/sfx   = compressed SFX

MASTERS:
  music/*.wav
  sfx/*.wav

Recommended:
- Music: stream from disk; loop tracks 01-03.
- SFX: preload short clips; crowd ambient can be streamed.
- Duck music 2-4 dB during whistle, round bell, and victory/defeat stings.
- Use randomized pitch +/- 3% on cloth, impacts and steps to reduce repetition.
